#ifndef __my_types_h__

typedef unsigned char u_int8_t;
typedef unsigned short u_int16_t;
typedef unsigned long u_int32_t;
typedef signed long int32_t;

typedef signed short int16_t;

#endif /* __my_types_h__ */

