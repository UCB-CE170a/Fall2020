echo "========install jhead======"
sudo apt-get install -y jhead

echo "======install ImageMagick==========="
wget https://www.imagemagick.org/download/ImageMagick.tar.gz
tar xvzf ImageMagick.tar.gz
cd ImageMagick-7.0.10-30
./configure 
make
sudo make install 
sudo ldconfig /usr/local/lib

echo "=====copy libANN_char.so to lib ========="
cp /content/bundler_sfm/bin/libANN_char.so /lib/