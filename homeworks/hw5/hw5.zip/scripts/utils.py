import numpy as np
from glob import glob 
import pandas as pd
import trusspy as tp

PLANE_NAMES = ['bottom','diagonal_left','diagonal_right','middle']
BASE_PATH = './data/strain_data/'

BOTTOM_MEMBERS = ['AD','AM','BC','DN','MB','NC']
DL_MEMBERS = ['AG','DG','DH','GE','GH','HE','HF']
DR_MEMBERS = ['BI','BJ','CJ','IE','IF','JF','JI']
MID_MEMBERS = ['GM','HN','MI','NJ']

PLANE2MEMBERS = {'bottom':BOTTOM_MEMBERS,
               'diagonal_left':DL_MEMBERS,
               'diagonal_right':DR_MEMBERS,
               'middle':MID_MEMBERS}

DESIGN_LOAD = 7000

def convert_time2load(time,T2LOAD):
    loads = []
    for t in time:
        if t > 58.29:
            load = T2LOAD[t]
        else:
            load = 0
        loads.append(load)
    return np.array(loads)


def get_member_fib(path):
    file_name = path.split('/')[-1]
    clean_name = file_name[:-4]
    member_name = clean_name[:2]
    fib = clean_name[3:]
    return member_name,fib
    
def add_strain_data(path,plane_data,T2LOAD):
    data_df = pd.read_csv(path,header = None)
    data = data_df.to_numpy(dtype='float')
    
    member_name,fib = get_member_fib(path)
    if member_name not in plane_data:
        plane_data[member_name] = {}
    member_data = plane_data[member_name]
    
    loc = data[0,1:]
    time = data[1:,0]
    load = convert_time2load(time,T2LOAD)
    strain = data[1:,1:]
    a = {'loc':loc,
                       'load':load,
                       'strain(micro)':strain} 
    member_data[fib] = a
    return plane_data
    
def get_plane_data(csv_paths,T2LOAD):
    plane_data = {}
    for path in csv_paths:
        plane_data = add_strain_data(path,plane_data,T2LOAD)
    return plane_data

def construct_strain_data(T2LOAD):
    STRAIN_DATA = {}
    for plane_name in PLANE_NAMES:
        data_paths = glob(BASE_PATH+plane_name+'/*.csv')
        plane_data = get_plane_data(data_paths,T2LOAD)
        STRAIN_DATA[plane_name] = plane_data
    return STRAIN_DATA



def create_truss_model(youngs_modulus):
    """
    Step 1: Assign Constant and initialze the model 
    """
    # # TODO: Assign proper value for the load below
    # LOAD = 3.5e3   # Total Load [N] 
    ELEMENT_TYPE   = 1    # truss
    MATERIAL_TYPE  = 2    # elasto-plastic
    YONGS_MODULUS = youngs_modulus # Young's modulus [Pa]
    HARDENING_MODULUS = 0.01 # hardening_modulus[Pa] a very small number for elastic-perfectly plastic
    YIELD_STRENGH = 350e6 # yield strength[Pa]
    A = 2.33e-5 # the area of the angle section [m^2]
    INCREMENT = 30

    M_perfect = tp.Model(log = 0)# Trusspy model initialization 
    # model settings
    M_perfect.Settings.dlpf = 0.1
    M_perfect.Settings.du = 0.002
    M_perfect.Settings.incs = INCREMENT
    M_perfect.Settings.stepcontrol = True

    """
    Step 2: Add truss elements to the model 
    """
    with M_perfect.Nodes as MN:# nodes defination unit [m]
        MN.add_node( 1, coord=(0,0,0))
        MN.add_node( 2, coord=(0.5,0,0))
        MN.add_node( 3, coord=(1,0,0))
        MN.add_node( 4, coord=(0.25,0,0.25))
        MN.add_node( 5, coord=(0.75,0,0.25))
        MN.add_node( 6, coord=(0.5,0,0.5))
        MN.add_node( 7, coord=(0,0.1438,0))
        MN.add_node( 8, coord=(0.5,0.1438,0))
        MN.add_node( 9, coord=(1,0.1438,0))
        MN.add_node( 10, coord=(0.25,0.1438,0.25))
        MN.add_node( 11, coord=(0.75,0.1438,0.25))
        MN.add_node( 12, coord=(0.5,0.1438,0.5))

    """
    Step 3: Add truss elements to the model 
    """
    with M_perfect.Elements as ME: 
        ME.add_element( 1, conn=(1,2), gprop=[A] )
        ME.add_element( 2 ,conn=(2,3), gprop=[A] )
        ME.add_element( 3, conn=(1,4), gprop=[A*2] )
        ME.add_element( 4, conn=(2,4), gprop=[A] )
        ME.add_element( 5, conn=(2,5), gprop=[A] )
        ME.add_element( 6, conn=(3,5), gprop=[A*2] )
        ME.add_element( 7, conn=(4,6), gprop=[A*2] )
        ME.add_element( 8, conn=(5,6), gprop=[A*2] )
        ME.add_element( 9, conn=(7,8), gprop=[A] )
        ME.add_element( 10 ,conn=(8,9), gprop=[A] )
        ME.add_element( 11, conn=(7,10), gprop=[A*2] )
        ME.add_element( 12, conn=(8,10), gprop=[A] )
        ME.add_element( 13, conn=(8,11), gprop=[A] )
        ME.add_element( 14, conn=(9,11), gprop=[A*2] )
        ME.add_element( 15, conn=(10,12), gprop=[A*2] )
        ME.add_element( 16, conn=(11,12), gprop=[A*2] )
        ME.add_element( 17, conn=(1,10), gprop=[A] )
        ME.add_element( 18, conn=(4,12), gprop=[A] )
        ME.add_element( 19, conn=(6,11), gprop=[A] )
        ME.add_element( 20, conn=(5,9), gprop=[A] )
        ME.add_element( 21, conn=(6,12), gprop=[A] )
        ME.add_element( 22, conn=(6,12), gprop=[A] )

        ME.add_element( 23, conn=(1,7), gprop=[A] )
        ME.add_element( 24, conn=(3,9), gprop=[A] )
        ME.add_element( 25, conn=(4,10), gprop=[A] )
        ME.add_element( 26, conn=(5,11), gprop=[A] )

        ME.assign_etype(    'all',   ELEMENT_TYPE   )
        ME.assign_mtype(    'all',  MATERIAL_TYPE   )
        ME.assign_material( 'all', [YONGS_MODULUS,HARDENING_MODULUS,YIELD_STRENGH] )

    """
    Step 4: Set boundary conditions and external forces
    """

    load = DESIGN_LOAD
    load1=-0.5*load # front force
    load2=-0.5*load # back force

    with M_perfect.Boundaries as MB: # boundary-displacement
        MB.add_bound_U( 1, (0,0,0) )
        MB.add_bound_U( 3, (1,1,0) )
        MB.add_bound_U( 7, (0,1,0) )
        MB.add_bound_U( 9, (1,1,0) )
        MB.add_bound_U( 2, (1,0,1) ) # this is a difference between our model and realistic word, since there is no joint in the real world for node 2 and 8
        MB.add_bound_U( 8, (1,0,1) ) # since there is no joint in the real world for node 2 and 8

    with M_perfect.ExtForces as MF: # boundary-force
        MF.add_force( 6, ( 0, 0, load1) )
        MF.add_force( 12, ( 0, 0, load2) )

    """
    Step 5: Build and run the model
    """
    M_perfect.build()
    M_perfect.run()
    print ("Simulation finished")
    return M_perfect

def get_rotation_degrees(M,elem):
  """Get rotation degrees of a element
    Args:
      M: trusspy model 
      elem: the element index of interest

    Returns:
      lpfs is a list of loading proportionality factor for this elem
      degrees is a list of rotation degree for this elem regarding to lpfs
  """
  con=M.Elements.conns[elem-1] # element names is 1 based whereas list index is 0 based
  node1,node2 =con[0], con[1]
  coord1,coord2=M.Nodes.coords[node1-1], M.Nodes.coords[node2-1]# node names is 1 based whereas list index is 0 based
  r_before = coord2-coord1 #initial vector representation of the truss element

  Res=M.Results.R
  lpfs,degrees = [],[]
  for Re in Res:
      n1_displacement = Re.U[node1-1]
      n2_displacement = Re.U[node2-1]
        
      # TODO: Get the coordinates of the two nodes after stressing. 
      coord1_after = coord1+n1_displacement
      coord2_after = coord2+n2_displacement
      # TODO: Use all the information to get the rotation degree:theta 
      # Hint: How do you get the angle of two vector? np.dot might be helpful
      r_after=coord2_after-coord1_after
      cosangle = r_before.dot(r_after)/(np.linalg.norm(r_before) * np.linalg.norm(r_after))
      theta=np.arccos(cosangle)
      lpfs.append(Re.lpf)
      degrees.append(np.degrees(theta))
  return np.array(lpfs),np.array(degrees)